package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.myapplication.R
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.IOException
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val wyslij = findViewById<Button>(R.id.wyslij_miasto)
        val miasto = findViewById<EditText>(R.id.miasto)
        val miasto2 = findViewById<TextView>(R.id.miasto2)
        val okHttpClient = OkHttpClient()
        wyslij.setOnClickListener{
            val request = Request.Builder()
                .url("https://danepubliczne.imgw.pl/api/data/synop")
                .build()
            okHttpClient.newCall(request).enqueue(object:Callback {
               override fun onFailure(call: Call, e: IOException) {
                    // Handle this
                }

                 override fun onResponse(call: Call, response: Response) {

                     miasto2.text = response.toString();
                }
            })
        }
        }
    }


